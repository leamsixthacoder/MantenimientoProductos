﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_Categoria
    {
        private int Idcategoria;
        private string Codigocategoria;
        private string Nombrecategoria;
        private string Descripcioncategoria;

        public int Idcategoria1 { get => Idcategoria; set => Idcategoria = value; }
        public string Codigocategoria1 { get => Codigocategoria; set => Codigocategoria = value; }
        public string Nombrecategoria1 { get => Nombrecategoria; set => Nombrecategoria = value; }
        public string Descripcioncategoria1 { get => Descripcioncategoria; set => Descripcioncategoria = value; }
    }
}
